package com.gamemon.app

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.WindowInsets
import android.widget.Button
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private companion object {
        const val REQ_SHIZUKU = 100
        const val REQ_NOTIF = 101
        const val SHIZUKU_PKG = "moe.shizuku.privileged.api"
        const val SHIZUKU_URL = "https://shizuku.rikka.app/download/"
        const val OPACITY_MIN = 20
        const val KEY_DIAG = "diag"
    }

    private lateinit var prefs: SharedPreferences
    private lateinit var txtShizuku: TextView
    private lateinit var btnShizuku: Button
    private lateinit var txtOverlay: TextView
    private lateinit var btnOverlay: Button
    private lateinit var txtNotif: TextView
    private lateinit var btnNotif: Button
    private lateinit var btnToggle: Button
    private lateinit var txtOpacity: TextView

    private val onBinder = Shizuku.OnBinderReceivedListener { runOnUiThread { refresh() } }
    private val onDead = Shizuku.OnBinderDeadListener { runOnUiThread { refresh() } }
    private val onPerm = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { refresh() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)

        val pad = (16 * resources.displayMetrics.density).toInt()
        findViewById<ScrollView>(R.id.root).setOnApplyWindowInsetsListener { v, insets ->
            val b = insets.getInsets(WindowInsets.Type.systemBars())
            v.setPadding(b.left + pad, b.top + pad, b.right + pad, b.bottom + pad)
            WindowInsets.CONSUMED
        }

        txtShizuku = findViewById(R.id.txtShizuku)
        btnShizuku = findViewById(R.id.btnShizuku)
        txtOverlay = findViewById(R.id.txtOverlay)
        btnOverlay = findViewById(R.id.btnOverlay)
        txtNotif = findViewById(R.id.txtNotif)
        btnNotif = findViewById(R.id.btnNotif)
        btnToggle = findViewById(R.id.btnToggle)
        txtOpacity = findViewById(R.id.txtOpacity)

        btnOverlay.setOnClickListener {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        btnNotif.setOnClickListener {
            if (Build.VERSION.SDK_INT >= 33) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
            }
        }
        btnToggle.setOnClickListener { onToggle() }

        findViewById<Button>(R.id.btnDiag).setOnClickListener { startDiag() }
        findViewById<Button>(R.id.btnCopy).setOnClickListener {
            val t = prefs.getString(KEY_DIAG, null)
            if (t == null) {
                Toast.makeText(this, R.string.diag_none, Toast.LENGTH_SHORT).show()
            } else {
                copyToClipboard(t)
                Toast.makeText(this, R.string.diag_copied, Toast.LENGTH_SHORT).show()
            }
        }

        // Ayarlar
        val seek = findViewById<SeekBar>(R.id.seekOpacity)
        seek.max = 100 - OPACITY_MIN
        val opacity = prefs.getInt(Prefs.OPACITY, 65).coerceIn(OPACITY_MIN, 100)
        seek.progress = opacity - OPACITY_MIN
        txtOpacity.text = getString(R.string.opacity_fmt, opacity)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                val v = progress + OPACITY_MIN
                txtOpacity.text = getString(R.string.opacity_fmt, v)
                prefs.edit().putInt(Prefs.OPACITY, v).apply()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        val radio = findViewById<RadioGroup>(R.id.radioInterval)
        radio.check(if (prefs.getInt(Prefs.INTERVAL, 1000) >= 2000) R.id.radio2 else R.id.radio1)
        radio.setOnCheckedChangeListener { _, id ->
            prefs.edit().putInt(Prefs.INTERVAL, if (id == R.id.radio2) 2000 else 1000).apply()
        }

        val lock = findViewById<Switch>(R.id.swLock)
        lock.isChecked = prefs.getBoolean(Prefs.LOCKED, false)
        lock.setOnCheckedChangeListener { _, c ->
            prefs.edit().putBoolean(Prefs.LOCKED, c).apply()
        }

        Shizuku.addBinderReceivedListenerSticky(onBinder)
        Shizuku.addBinderDeadListener(onDead)
        Shizuku.addRequestPermissionResultListener(onPerm)
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(onBinder)
        Shizuku.removeBinderDeadListener(onDead)
        Shizuku.removeRequestPermissionResultListener(onPerm)
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    private fun onToggle() {
        val svc = Intent(this, OverlayService::class.java)
        if (OverlayService.running) {
            stopService(svc)
        } else if (!Settings.canDrawOverlays(this)) {
            btnOverlay.performClick()
            return
        } else {
            startForegroundService(svc)
        }
        btnToggle.postDelayed({ refresh() }, 400)
    }

    private fun startDiag() {
        if (!Shell.ready()) {
            Toast.makeText(this, R.string.diag_noshizuku, Toast.LENGTH_LONG).show()
            return
        }
        Toast.makeText(this, R.string.diag_started, Toast.LENGTH_LONG).show()
        val script = try {
            assets.open("diag.sh").bufferedReader().use { it.readText() }
        } catch (_: Throwable) {
            ""
        }
        Thread {
            val out = Shell.exec(script, 40000L) ?: "Rapor alinamadi (Shizuku yanit vermedi)"
            prefs.edit().putString(KEY_DIAG, out).apply()
            copyToClipboard(out)
        }.start()
    }

    private fun copyToClipboard(text: String) {
        try {
            val cm = getSystemService(ClipboardManager::class.java)
            cm.setPrimaryClip(ClipData.newPlainText("GameMon rapor", text))
        } catch (_: Throwable) {
        }
    }

    private fun shizukuInstalled(): Boolean = try {
        packageManager.getPackageInfo(SHIZUKU_PKG, 0)
        true
    } catch (_: Exception) {
        false
    }

    private fun setStatus(tv: TextView, text: String, ok: Boolean) {
        tv.text = text
        tv.setTextColor(getColor(if (ok) R.color.green else R.color.yellow))
    }

    private fun refresh() {
        // Shizuku
        val running = try {
            Shizuku.pingBinder()
        } catch (_: Throwable) {
            false
        }
        val granted = running && try {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (_: Throwable) {
            false
        }
        when {
            granted -> {
                setStatus(txtShizuku, getString(R.string.sh_ok), true)
                btnShizuku.visibility = View.GONE
            }
            running -> {
                setStatus(txtShizuku, getString(R.string.sh_perm), false)
                btnShizuku.text = getString(R.string.btn_grant)
                btnShizuku.visibility = View.VISIBLE
                btnShizuku.setOnClickListener {
                    try {
                        Shizuku.requestPermission(REQ_SHIZUKU)
                    } catch (_: Throwable) {
                    }
                }
            }
            shizukuInstalled() -> {
                setStatus(txtShizuku, getString(R.string.sh_off), false)
                btnShizuku.text = getString(R.string.btn_open)
                btnShizuku.visibility = View.VISIBLE
                btnShizuku.setOnClickListener {
                    packageManager.getLaunchIntentForPackage(SHIZUKU_PKG)?.let { startActivity(it) }
                }
            }
            else -> {
                setStatus(txtShizuku, getString(R.string.sh_missing), false)
                btnShizuku.text = getString(R.string.btn_get)
                btnShizuku.visibility = View.VISIBLE
                btnShizuku.setOnClickListener {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(SHIZUKU_URL)))
                }
            }
        }

        // Üstte gösterme
        val overlayOk = Settings.canDrawOverlays(this)
        setStatus(txtOverlay, getString(if (overlayOk) R.string.ov_ok else R.string.ov_no), overlayOk)
        btnOverlay.visibility = if (overlayOk) View.GONE else View.VISIBLE

        // Bildirim (Android 13+)
        val notifOk = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        setStatus(txtNotif, getString(if (notifOk) R.string.nt_ok else R.string.nt_no), notifOk)
        btnNotif.visibility = if (notifOk) View.GONE else View.VISIBLE

        btnToggle.text = getString(if (OverlayService.running) R.string.btn_stop else R.string.btn_start)
    }
}
