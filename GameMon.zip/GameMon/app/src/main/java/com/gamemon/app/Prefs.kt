package com.gamemon.app

object Prefs {
    const val NAME = "gamemon"
    const val OPACITY = "opacity"   // 20..95 (arka plan koyuluğu, yüzde)
    const val INTERVAL = "interval" // ms
    const val LOCKED = "locked"     // true: pencere dokunuşları oyuna geçirir
}
