package com.gamemon.app

import android.graphics.Typeface
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import java.util.Locale
import kotlin.math.roundToInt

/** Yüzen pencerenin metnini üretir: etiket koyu yeşil, değer yeşil, uyarı sarı. */
object Render {

    val LABEL = 0xFF5FA777.toInt()
    val OK = 0xFF00FF85.toInt()
    val WARN = 0xFFFFD600.toInt()

    private const val CPU_GPU_HOT_C = 75f
    private const val BAT_HOT_C = 42f
    private const val SKIN_HOT_C = 42f
    private const val LOAD_HIGH = 85f
    private const val RAM_HIGH = 90f

    private fun f(fmt: String, vararg a: Any): String = String.format(Locale.US, fmt, *a)

    private fun SpannableStringBuilder.put(text: String, color: Int, bold: Boolean = false): SpannableStringBuilder {
        val s = length
        append(text)
        setSpan(ForegroundColorSpan(color), s, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (bold) setSpan(StyleSpan(Typeface.BOLD), s, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return this
    }

    private fun SpannableStringBuilder.value(text: String, warn: Boolean): SpannableStringBuilder =
        put(text, if (warn) WARN else OK, warn)

    private fun hot(v: Float?, limit: Float) = v != null && v >= limit

    private fun pct(v: Int?) = if (v == null) " --%" else f("%3d%%", v)
    private fun ghz(mhz: Int?) = if (mhz == null) " --G" else f("%.1fG", mhz / 1000f)
    private fun mhzStr(mhz: Int?) = if (mhz == null) "  --M" else f("%4dM", mhz)
    private fun temp(t: Float?) = if (t == null) "--°" else f("%2d°", t.roundToInt())

    fun boot(text: String): SpannableStringBuilder =
        SpannableStringBuilder().put(text, OK)

    fun build(
        shellOk: Boolean,
        s: Sample?,
        fpsWarn: Boolean,
        ramGb: Float,
        ramPct: Int,
        batC: Float?
    ): SpannableStringBuilder {
        val sb = SpannableStringBuilder()

        // FPS
        sb.put("FPS ", LABEL)
        val fps = s?.fps
        if (!shellOk) {
            sb.put("Shizuku bağlı değil", WARN, true)
        } else if (fps == null) {
            sb.put(" --", OK)
            val note = s?.fpsNote
            if (note != null) sb.put("  $note", LABEL)
        } else {
            sb.value(f("%3d", fps.roundToInt()), fpsWarn)
            if (fps > 0f) sb.put(f("  %.1fms", 1000f / fps), LABEL)
        }
        sb.append('\n')

        // CPU
        val cpuPct = s?.cpuPct
        sb.put("CPU ", LABEL)
        sb.value(pct(cpuPct), hot(cpuPct?.toFloat(), LOAD_HIGH))
        sb.put(" " + ghz(s?.cpuMhz) + " ", OK)
        sb.value(temp(s?.cpuTemp), hot(s?.cpuTemp, CPU_GPU_HOT_C))
        sb.append('\n')

        // GPU
        val gpuPct = s?.gpuPct
        sb.put("GPU ", LABEL)
        if (gpuPct == null && s?.gpuMhz == null) {
            // Bazı telefonlar GPU yükünü uygulamalara kapatır; "--" yerine açıkça belirt.
            sb.put("yük yok".padEnd(10), LABEL)
        } else {
            sb.value(pct(gpuPct), hot(gpuPct?.toFloat(), LOAD_HIGH))
            sb.put(" " + mhzStr(s?.gpuMhz) + " ", OK)
        }
        sb.value(temp(s?.gpuTemp), hot(s?.gpuTemp, CPU_GPU_HOT_C))
        sb.append('\n')

        // RAM + pil
        sb.put("RAM ", LABEL)
        sb.value(pct(ramPct), ramPct >= RAM_HIGH)
        sb.put(" " + f("%.1fG", ramGb), OK)
        sb.append('\n')

        // Pil ve gövde (yüzey) sıcaklığı; CPU/GPU satırındaki sıcaklık işlemcinin kendi sıcaklığı
        sb.put("BAT ", LABEL)
        sb.value(temp(batC), hot(batC, BAT_HOT_C))
        sb.put("  GÖVDE ", LABEL)
        sb.value(temp(s?.skinTemp), hot(s?.skinTemp, SKIN_HOT_C))

        return sb
    }
}
