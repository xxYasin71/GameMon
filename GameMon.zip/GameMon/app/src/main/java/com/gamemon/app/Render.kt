package com.gamemon.app

import android.graphics.Typeface
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import java.util.Locale
import kotlin.math.roundToInt

/** Yüzen pencere yalnızca istenen beş ölçümü gösterir. */
object Render {
    val LABEL = 0xFF5FA777.toInt()
    val OK = 0xFF00FF85.toInt()
    val WARN = 0xFFFFD600.toInt()

    private const val BAT_HOT_C = 42f
    private const val SKIN_HOT_C = 42f
    private const val LOAD_HIGH = 85f
    private const val RAM_HIGH = 90f

    private fun f(fmt: String, vararg a: Any): String = String.format(Locale.US, fmt, *a)
    private fun SpannableStringBuilder.put(text: String, color: Int, bold: Boolean = false): SpannableStringBuilder {
        val start = length
        append(text)
        setSpan(ForegroundColorSpan(color), start, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (bold) setSpan(StyleSpan(Typeface.BOLD), start, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return this
    }
    private fun SpannableStringBuilder.value(text: String, warn: Boolean) = put(text, if (warn) WARN else OK, warn)
    private fun temp(t: Float?) = if (t == null) "--°" else f("%2d°", t.roundToInt())

    fun boot(text: String): SpannableStringBuilder = SpannableStringBuilder().put(text, OK)

    fun build(shellOk: Boolean, s: Sample?, fpsWarn: Boolean, ramGb: Float, ramPct: Int, batC: Float?): SpannableStringBuilder {
        val sb = SpannableStringBuilder()
        sb.put("FPS ", LABEL)
        val fps = s?.fps
        if (!shellOk) sb.put("Shizuku bağlı değil", WARN, true)
        else if (fps == null) {
            sb.put(" --", OK)
            s?.fpsNote?.let { sb.put("  $it", LABEL) }
        } else {
            sb.value(f("%3d", fps.roundToInt()), fpsWarn)
            if (fps > 0f) sb.put(f("  %.1fms", 1000f / fps), LABEL)
        }
        sb.append('\n')

        val cpuPct = s?.cpuPct
        sb.put("CPU ", LABEL)
        sb.value(if (cpuPct == null) " --%" else f("%3d%%", cpuPct), cpuPct != null && cpuPct >= LOAD_HIGH)
        sb.append('\n')

        sb.put("RAM ", LABEL)
        sb.value(f("%3d%%", ramPct), ramPct >= RAM_HIGH)
        sb.put(" " + f("%.1fG", ramGb), OK)
        sb.append('\n')

        sb.put("BAT ", LABEL)
        sb.value(temp(batC), batC != null && batC >= BAT_HOT_C)
        sb.put("  CİHAZ ", LABEL)
        sb.value(temp(s?.skinTemp), s?.skinTemp != null && s.skinTemp >= SKIN_HOT_C)
        return sb
    }
}
