package com.gamemon.app

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.lang.reflect.Method
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

/** Shizuku üzerinden shell yetkisiyle komut çalıştırır. */
object Shell {

    private val pool = Executors.newCachedThreadPool { r ->
        Thread(r, "gamemon-io").apply { isDaemon = true }
    }

    // Shizuku 13+ newProcess'i private yaptı, yansıma ile çağrılıyor.
    private val newProcess: Method? by lazy {
        try {
            Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            ).apply { isAccessible = true }
        } catch (_: Throwable) {
            null
        }
    }

    fun ready(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) {
        false
    }

    /** Betiği `sh -c` ile çalıştırıp stdout'u döndürür. Hata ya da zaman aşımında null. */
    fun exec(script: String, timeoutMs: Long = 5000L): String? {
        val m = newProcess ?: return null
        var proc: Process? = null
        return try {
            val p = m.invoke(null, arrayOf("sh", "-c", script), null, null) as Process
            proc = p
            val fut = pool.submit(Callable {
                p.inputStream.use { it.readBytes() }.toString(Charsets.UTF_8)
            })
            try {
                fut.get(timeoutMs, TimeUnit.MILLISECONDS)
            } catch (_: TimeoutException) {
                fut.cancel(true)
                null
            }
        } catch (_: Throwable) {
            null
        } finally {
            try {
                proc?.destroy()
            } catch (_: Throwable) {
            }
        }
    }
}
