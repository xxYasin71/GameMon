package com.gamemon.app

import android.os.SystemClock
import java.util.Arrays
import java.util.Locale

data class Sample(
    val fps: Float?,
    val cpuPct: Int?,
    val cpuMhz: Int?,
    val cpuTemp: Float?,
    val gpuPct: Int?,
    val gpuMhz: Int?,
    val gpuTemp: Float?
)

/**
 * Tek bir shell çağrısıyla tüm ölçümleri toplar ve ayrıştırır.
 * Yalnızca örnekleme iş parçacığından çağrılmalı (iç durum paylaşımlı değil).
 */
class Sampler(private val scriptBody: String, private val ownPkg: String) {

    private val ws = Regex("\\s+")
    private val fgRe = Regex("ActivityRecord\\{\\S+ u\\d+ ([A-Za-z0-9_.]+)/")
    private val thermRe = Regex("mValue=(-?[0-9.]+), mType=(\\d+)")

    private var prevTotal = 0L
    private var prevIdle = 0L

    private var zonesReady = false
    private var cpuZones: Set<String> = emptySet()
    private var gpuZones: Set<String> = emptySet()

    private var pkg = ""
    private var lastFgCheck = 0L
    private val lastNewest = HashMap<String, Long>()

    fun sample(): Sample? {
        if (!zonesReady) discoverZones()

        val now = SystemClock.elapsedRealtime()
        val wantFg = now - lastFgCheck >= 2000L
        if (wantFg) lastFgCheck = now

        val zones = (cpuZones + gpuZones).joinToString(" ")
        val target = if (pkg == ownPkg) "" else pkg
        val raw = Shell.exec(header("sample", target, zones, wantFg, zones.isEmpty()) + scriptBody)
            ?: return null
        return parse(raw)
    }

    private fun header(mode: String, pkg: String, zones: String, fg: Boolean, dt: Boolean): String =
        "MODE='$mode'\nPKG='$pkg'\nZONES='$zones'\nWANT_FG=${if (fg) 1 else 0}\nWANT_DT=${if (dt) 1 else 0}\n"

    private fun discoverZones() {
        val raw = Shell.exec(header("discover", "", "", false, false) + scriptBody) ?: return
        val cpu = LinkedHashSet<String>()
        val gpu = LinkedHashSet<String>()
        for (line in raw.lineSequence()) {
            val i = line.indexOf(' ')
            if (i <= 0) continue
            val path = line.substring(0, i)
            val type = line.substring(i + 1).trim().lowercase(Locale.ROOT)
            if (type.isEmpty()) continue
            when {
                type.contains("gpu") || type.contains("g3d") || type.contains("mali") -> gpu.add(path)
                type.contains("cpu") || type.contains("soc") ||
                    type == "big" || type == "mid" || type == "little" -> cpu.add(path)
            }
        }
        cpuZones = cpu.take(24).toSet()
        gpuZones = gpu.take(8).toSet()
        zonesReady = true
    }

    private fun parse(raw: String): Sample {
        val sec = HashMap<String, ArrayList<String>>()
        val lat = ArrayList<Pair<String, ArrayList<String>>>()
        var cur: ArrayList<String>? = null
        for (line in raw.lineSequence()) {
            if (line.startsWith("@@")) {
                val name = line.substring(2).trim()
                cur = when {
                    name == "END" -> null
                    name.startsWith("LAT ") -> ArrayList<String>().also { lat.add(name.substring(4) to it) }
                    else -> sec.getOrPut(name) { ArrayList() }
                }
            } else {
                cur?.add(line)
            }
        }

        // --- Ön plandaki uygulama
        val fgLines = sec["FG"]
        if (fgLines != null && fgLines.isNotEmpty()) {
            val ordered = fgLines.filter { it.contains("topResumedActivity") } + fgLines
            for (l in ordered) {
                val m = fgRe.find(l)
                if (m != null) {
                    pkg = m.groupValues[1]
                    break
                }
            }
        }

        // --- CPU yükü (/proc/stat farkı)
        var cpuPct: Int? = null
        val st = sec["STAT"]?.firstOrNull { it.startsWith("cpu") }
        if (st != null) {
            val t = st.trim().split(ws).drop(1).mapNotNull { it.toLongOrNull() }
            if (t.size >= 5) {
                val idle = t[3] + t[4]
                val total = t.take(8).sum()
                if (prevTotal > 0L && total > prevTotal) {
                    val dT = total - prevTotal
                    val dI = idle - prevIdle
                    cpuPct = (100L * (dT - dI) / dT).toInt().coerceIn(0, 100)
                }
                prevTotal = total
                prevIdle = idle
            }
        }

        // --- CPU frekansı (en yüksek çekirdek)
        var cpuMhz: Int? = null
        val cf = sec["CPUF"]
        if (cf != null) {
            val m = cf.mapNotNull { it.trim().toLongOrNull() }.maxOrNull()
            if (m != null && m > 0L) cpuMhz = (m / 1000L).toInt()
        }

        // --- Sıcaklıklar
        var cpuT: Float? = null
        var gpuT: Float? = null
        val zl = sec["ZONES"]
        if (zl != null) {
            for (l in zl) {
                val i = l.lastIndexOf(' ')
                if (i <= 0) continue
                val path = l.substring(0, i).trim()
                val t = normTemp(l.substring(i + 1)) ?: continue
                if (path in cpuZones) cpuT = maxOf(cpuT ?: t, t)
                else if (path in gpuZones) gpuT = maxOf(gpuT ?: t, t)
            }
        }
        val dt = sec["DT"]
        if (dt != null && cpuT == null && gpuT == null) {
            for (l in dt) {
                val m = thermRe.find(l) ?: continue
                val v = m.groupValues[1].toFloatOrNull() ?: continue
                when (m.groupValues[2]) {
                    "0" -> cpuT = maxOf(cpuT ?: v, v)
                    "1" -> gpuT = maxOf(gpuT ?: v, v)
                }
            }
        }

        // --- GPU yükü
        var gpuPct: Int? = null
        val gl = sec["GPU"]
        if (gl != null) {
            for (l in gl) {
                val i = l.indexOf(' ')
                if (i <= 0) continue
                val path = l.substring(0, i)
                val nums = l.substring(i + 1).trim().split(ws).mapNotNull { it.toLongOrNull() }
                val v: Int? = if (path.endsWith("gpubusy")) {
                    if (nums.size >= 2 && nums[1] > 0L) (nums[0] * 100L / nums[1]).toInt() else null
                } else {
                    nums.firstOrNull()?.toInt()
                }
                if (v != null) {
                    gpuPct = v.coerceIn(0, 100)
                    break
                }
            }
        }

        // --- GPU frekansı
        var gpuMhz: Int? = null
        val gf = sec["GPUF"]
        if (gf != null) {
            for (l in gf) {
                val i = l.indexOf(' ')
                if (i <= 0) continue
                val v = l.substring(i + 1).trim().split(ws).firstOrNull()?.toLongOrNull() ?: continue
                val mhz = when {
                    v >= 10_000_000L -> v / 1_000_000L // Hz
                    v >= 10_000L -> v / 1_000L         // kHz
                    else -> v                          // MHz
                }
                if (mhz > 0L) {
                    gpuMhz = mhz.toInt()
                    break
                }
            }
        }

        // --- FPS: katman başına hesapla, en yüksek olanı al
        var fps: Float? = null
        if (lat.isNotEmpty()) {
            if (lastNewest.size > 48) lastNewest.clear()
            var best = -1f
            for ((name, lines) in lat) {
                val f = fpsOf(name, lines) ?: continue
                if (f > best) best = f
            }
            if (best >= 0f) fps = best
        }

        return Sample(fps, cpuPct, cpuMhz, cpuT, gpuPct, gpuMhz, gpuT)
    }

    /**
     * `dumpsys SurfaceFlinger --latency` çıktısı: ilk satır yenileme periyodu, sonra
     * her satırda [istenen, gerçek sunum, hazır] zaman damgası (ns). Son 1 saniyedeki
     * gerçek sunum zamanlarından FPS çıkarılır. Yeni kare yoksa 0 döner.
     */
    private fun fpsOf(name: String, lines: List<String>): Float? {
        val ts = LongArray(lines.size)
        var n = 0
        for (l in lines) {
            val p = l.trim().split(ws)
            if (p.size != 3) continue
            val a = p[1].toLongOrNull() ?: continue
            if (a <= 0L || a == Long.MAX_VALUE) continue
            ts[n++] = a
        }
        if (n < 2) return null
        Arrays.sort(ts, 0, n)
        val newest = ts[n - 1]
        val prev = lastNewest.put(name, newest)
        if (prev != null && prev == newest) return 0f // yeni kare gelmedi

        val cutoff = newest - 1_000_000_000L
        var first = 0
        while (first < n - 1 && ts[first] < cutoff) first++
        val count = n - first
        if (count < 2) return 0f
        val span = newest - ts[first]
        if (span <= 0L) return null
        return (count - 1) * 1_000_000_000f / span
    }

    private fun normTemp(raw: String): Float? {
        val v = raw.trim().toFloatOrNull() ?: return null
        val c = when {
            v >= 1000f -> v / 1000f
            v >= 150f -> v / 10f
            else -> v
        }
        return if (c in 1f..150f) c else null
    }
}
