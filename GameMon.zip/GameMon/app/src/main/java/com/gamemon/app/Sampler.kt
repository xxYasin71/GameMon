package com.gamemon.app

import android.os.SystemClock
import java.util.Locale

data class Sample(
    val fps: Float?,
    val fpsNote: String?,
    val cpuPct: Int?,
    val cpuMhz: Int?,
    val cpuTemp: Float?,
    val gpuPct: Int?,
    val gpuMhz: Int?,
    val gpuTemp: Float?,
    val skinTemp: Float?
)

/**
 * Tek bir shell çağrısıyla tüm ölçümleri toplar ve ayrıştırır.
 * Yalnızca örnekleme iş parçacığından çağrılmalı (iç durum paylaşımlı değil).
 */
class Sampler(private val scriptBody: String, private val ownPkg: String) {

    private val ws = Regex("\\s+")
    private val fgRe = Regex("ActivityRecord\\{\\S+ u\\d+ ([A-Za-z0-9_.]+)/")
    private val thermRe = Regex("mValue=(-?[0-9.]+), mType=(\\d+)")
    private val layerNameRe = Regex("^\\s*layerName\\s*=\\s*(.+)$")
    private val totalFramesRe = Regex("^\\s*totalFrames\\s*=\\s*(\\d+)")

    private var prevTotal = 0L
    private var prevIdle = 0L

    private var zonesReady = false
    private var cpuZones: Set<String> = emptySet()
    private var gpuZones: Set<String> = emptySet()

    private var pkg = ""
    private var lastFgCheck = 0L
    private data class FrameCounter(val frames: Long, val timeMs: Long)
    private val previousFrames = HashMap<String, FrameCounter>()
    private var timestatsStarted = false

    fun sample(): Sample? {
        if (!zonesReady) discoverZones()

        val now = SystemClock.elapsedRealtime()
        val wantFg = now - lastFgCheck >= 2000L
        if (wantFg) lastFgCheck = now

        val zones = (cpuZones + gpuZones).joinToString(" ")
        val target = if (pkg == ownPkg) "" else pkg
        val startTimestats = !timestatsStarted
        val raw = Shell.exec(header("sample", target, zones, wantFg, true, startTimestats) + scriptBody)
            ?: return null
        if (startTimestats) timestatsStarted = true
        return parse(raw)
    }

    private fun header(mode: String, pkg: String, zones: String, fg: Boolean, dt: Boolean, tsStart: Boolean = false): String =
        "MODE='$mode'\nPKG='$pkg'\nZONES='$zones'\nWANT_FG=${if (fg) 1 else 0}\nWANT_DT=${if (dt) 1 else 0}\nWANT_TS_START=${if (tsStart) 1 else 0}\n"

    private fun discoverZones() {
        val raw = Shell.exec(header("discover", "", "", false, false) + scriptBody) ?: return
        val cpu = LinkedHashSet<String>()
        val gpu = LinkedHashSet<String>()
        for (line in raw.lineSequence()) {
            val i = line.indexOf(' ')
            if (i <= 0) continue
            val path = line.substring(0, i)
            val type = line.substring(i + 1).trim().lowercase(Locale.ROOT)
            if (type.isEmpty()) continue
            when {
                type.contains("gpu") || type.contains("g3d") || type.contains("mali") -> gpu.add(path)
                type.contains("cpu") || type.contains("soc") ||
                    type == "big" || type == "mid" || type == "little" -> cpu.add(path)
            }
        }
        cpuZones = cpu.take(24).toSet()
        gpuZones = gpu.take(8).toSet()
        zonesReady = true
    }

    private fun parse(raw: String): Sample {
        val sec = HashMap<String, ArrayList<String>>()
        var cur: ArrayList<String>? = null
        for (line in raw.lineSequence()) {
            if (line.startsWith("@@")) {
                val name = line.substring(2).trim()
                cur = when {
                    name == "END" -> null
                    else -> sec.getOrPut(name) { ArrayList() }
                }
            } else {
                cur?.add(line)
            }
        }

        // --- Ön plandaki uygulama
        val fgLines = sec["FG"]
        if (fgLines != null && fgLines.isNotEmpty()) {
            val ordered = fgLines.filter { it.contains("topResumedActivity") } + fgLines
            for (l in ordered) {
                val m = fgRe.find(l)
                if (m != null) {
                    pkg = m.groupValues[1]
                    break
                }
            }
        }

        // --- CPU yükü (/proc/stat farkı)
        var cpuPct: Int? = null
        val st = sec["STAT"]?.firstOrNull { it.startsWith("cpu") }
        if (st != null) {
            val t = st.trim().split(ws).drop(1).mapNotNull { it.toLongOrNull() }
            if (t.size >= 5) {
                val idle = t[3] + t[4]
                val total = t.take(8).sum()
                if (prevTotal > 0L && total > prevTotal) {
                    val dT = total - prevTotal
                    val dI = idle - prevIdle
                    cpuPct = (100L * (dT - dI) / dT).toInt().coerceIn(0, 100)
                }
                prevTotal = total
                prevIdle = idle
            }
        }

        // --- CPU frekansı (en yüksek çekirdek)
        var cpuMhz: Int? = null
        val cf = sec["CPUF"]
        if (cf != null) {
            val m = cf.mapNotNull { it.trim().toLongOrNull() }.maxOrNull()
            if (m != null && m > 0L) cpuMhz = (m / 1000L).toInt()
        }

        // --- Sıcaklıklar: önce sistemin termal servisi (HAL), yoksa termal bölgelerin ortancası.
        // Tek bir bozuk sensör değeri sonucu bozmasın diye en yüksek değil ortanca alınır.
        val cpuVals = ArrayList<Float>()
        val gpuVals = ArrayList<Float>()
        val zl = sec["ZONES"]
        if (zl != null) {
            for (l in zl) {
                val i = l.lastIndexOf(' ')
                if (i <= 0) continue
                val path = l.substring(0, i).trim()
                val t = normTemp(l.substring(i + 1)) ?: continue
                if (path in cpuZones) cpuVals.add(t)
                else if (path in gpuZones) gpuVals.add(t)
            }
        }
        var halCpu: Float? = null
        var halGpu: Float? = null
        var halSkin: Float? = null
        val dt = sec["DT"]
        if (dt != null) {
            for (l in dt) {
                val m = thermRe.find(l) ?: continue
                val v = m.groupValues[1].toFloatOrNull() ?: continue
                if (v < 15f || v > 110f) continue
                // Çıktıda önce eski "cached" değerler, en sonda anlık HAL değerleri var: sonuncu geçerli.
                when (m.groupValues[2]) {
                    "0" -> halCpu = v
                    "1" -> halGpu = v
                    "3" -> halSkin = v
                }
            }
        }
        val cpuT: Float? = halCpu ?: median(cpuVals)
        val gpuT: Float? = halGpu ?: median(gpuVals)

        // --- GPU yükü
        var gpuPct: Int? = null
        val gl = sec["GPU"]
        if (gl != null) {
            for (l in gl) {
                val i = l.indexOf(' ')
                if (i <= 0) continue
                val path = l.substring(0, i)
                val nums = l.substring(i + 1).trim().split(ws).mapNotNull { it.toLongOrNull() }
                val v: Int? = if (path.endsWith("gpubusy")) {
                    if (nums.size >= 2 && nums[1] > 0L) (nums[0] * 100L / nums[1]).toInt() else null
                } else {
                    nums.firstOrNull()?.toInt()
                }
                if (v != null) {
                    gpuPct = v.coerceIn(0, 100)
                    break
                }
            }
        }

        // --- GPU frekansı
        var gpuMhz: Int? = null
        val gf = sec["GPUF"]
        if (gf != null) {
            for (l in gf) {
                val i = l.indexOf(' ')
                if (i <= 0) continue
                val v = l.substring(i + 1).trim().split(ws).firstOrNull()?.toLongOrNull() ?: continue
                val mhz = when {
                    v >= 10_000_000L -> v / 1_000_000L // Hz
                    v >= 10_000L -> v / 1_000L         // kHz
                    else -> v                          // MHz
                }
                if (mhz > 0L) {
                    gpuMhz = mhz.toInt()
                    break
                }
            }
        }

        // --- FPS: SurfaceFlinger TimeStats toplam kare sayacının örnekler arası farkı.
        // Android 16 / HyperOS 3'te --latency yalnızca yenileme periyodu döndürebiliyor.
        val fps = fpsFromTimeStats(sec["TS"].orEmpty(), pkg, SystemClock.elapsedRealtime())
        val fpsNote: String? = if (fps != null) null else when {
            pkg.isEmpty() -> "oyun bekleniyor"
            sec["TS"].isNullOrEmpty() -> "timestats?"
            else -> "ölçülüyor"
        }

        return Sample(fps, fpsNote, cpuPct, cpuMhz, cpuT, gpuPct, gpuMhz, gpuT, halSkin)
    }

    /** SurfaceFlinger TimeStats totalFrames sayacının örnekler arası farkından FPS hesaplar. */
    private fun fpsFromTimeStats(lines: List<String>, foregroundPackage: String, nowMs: Long): Float? {
        if (foregroundPackage.isBlank() || lines.isEmpty()) return null

        data class LayerFrames(val name: String, val frames: Long)
        val layers = ArrayList<LayerFrames>()
        var layerName: String? = null
        var totalFrames: Long? = null

        fun flush() {
            val name = layerName
            val frames = totalFrames
            if (name != null && frames != null && name.contains(foregroundPackage) &&
                name.contains("SurfaceView[")) layers.add(LayerFrames(name, frames))
        }

        for (line in lines) {
            val nameMatch = layerNameRe.find(line)
            if (nameMatch != null) {
                flush()
                layerName = nameMatch.groupValues[1].trim()
                totalFrames = null
                continue
            }
            val countMatch = totalFramesRe.find(line)
            if (countMatch != null) totalFrames = countMatch.groupValues[1].toLongOrNull()
        }
        flush()
        if (layers.isEmpty()) return null

        val candidates = ArrayList<Pair<Boolean, Float>>()
        for (layer in layers) {
            val previous = previousFrames.put(layer.name, FrameCounter(layer.frames, nowMs)) ?: continue
            val elapsed = nowMs - previous.timeMs
            val delta = layer.frames - previous.frames
            if (elapsed <= 0L || delta < 0L) continue
            val value = delta * 1000f / elapsed
            if (value.isFinite() && value in 0f..240f) {
                candidates.add(layer.name.contains("BLAST", ignoreCase = true) to value)
            }
        }

        // BLAST SurfaceView, oyun görüntüsünün sunulduğu ana katman olma olasılığı en yüksek adaydır.
        return candidates.maxWithOrNull(compareBy<Pair<Boolean, Float>> { it.first }.thenBy { it.second })?.second
    }

    private fun median(v: List<Float>): Float? {
        if (v.isEmpty()) return null
        val s = v.sorted()
        return s[s.size / 2]
    }

    private fun normTemp(raw: String): Float? {
        val v = raw.trim().toFloatOrNull() ?: return null
        val c = when {
            v >= 1000f -> v / 1000f
            v >= 150f -> v / 10f
            else -> v
        }
        return if (c in 15f..110f) c else null
    }
}
