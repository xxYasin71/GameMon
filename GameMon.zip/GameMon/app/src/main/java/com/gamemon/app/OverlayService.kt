package com.gamemon.app

import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import kotlin.math.roundToInt

class OverlayService : Service() {

    companion object {
        @Volatile
        var running = false

        private const val CHANNEL = "gamemon_overlay"
        private const val NOTIF_ID = 4201
        private const val ACTION_STOP = "com.gamemon.app.STOP"
    }

    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private lateinit var lp: WindowManager.LayoutParams
    private val main = Handler(Looper.getMainLooper())
    private var view: TextView? = null
    private var worker: Thread? = null

    @Volatile
    private var alive = false
    private var fpsPeak = 0f

    private val baseFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == Prefs.OPACITY || key == Prefs.LOCKED) main.post { applyStyle() }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) stopSelf()
        return START_NOT_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
        startInForeground()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        createOverlay()
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        running = true
        alive = true
        startWorker()
    }

    override fun onDestroy() {
        alive = false
        running = false
        worker?.interrupt()
        if (::prefs.isInitialized) prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        view?.let {
            try {
                wm.removeView(it)
            } catch (_: Throwable) {
            }
        }
        view = null
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        main.post {
            val v = view ?: return@post
            loadPosition()
            if (v.isAttachedToWindow) wm.updateViewLayout(v, lp)
        }
    }

    // ---------------------------------------------------------------- bildirim

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "GameMon", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val action = Notification.Action.Builder(
            Icon.createWithResource(this, R.drawable.ic_stat),
            getString(R.string.notif_stop),
            stop
        ).build()
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setContentIntent(open)
            .addAction(action)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ---------------------------------------------------------------- pencere

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun posKey(axis: String): String {
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        return axis + if (land) "_l" else "_p"
    }

    private fun loadPosition() {
        val dm = resources.displayMetrics
        lp.x = prefs.getInt(posKey("x"), dp(16)).coerceIn(0, maxOf(0, dm.widthPixels - dp(120)))
        lp.y = prefs.getInt(posKey("y"), dp(64)).coerceIn(0, maxOf(0, dm.heightPixels - dp(80)))
    }

    private fun savePosition() {
        prefs.edit().putInt(posKey("x"), lp.x).putInt(posKey("y"), lp.y).apply()
    }

    private fun createOverlay() {
        val tv = TextView(this)
        tv.typeface = Typeface.MONOSPACE
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        tv.includeFontPadding = false
        tv.setPadding(dp(8), dp(6), dp(8), dp(6))
        tv.text = Render.boot(getString(R.string.overlay_boot))

        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            baseFlags,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        // Android 12+ alfa 0.8'in üstündeki dokunulmaz pencerelerden geçen dokunuşları engeller.
        // Kilitliyken oyuna dokunuş geçebilsin diye 0.8'in altında tutuyoruz.
        lp.alpha = 0.79f
        loadPosition()

        view = tv
        applyStyle()

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        tv.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = lp.x
                    startY = lp.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = startX + (e.rawX - downX).toInt()
                    lp.y = startY + (e.rawY - downY).toInt()
                    wm.updateViewLayout(tv, lp)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    savePosition()
                    true
                }
                else -> false
            }
        }

        wm.addView(tv, lp)
    }

    private fun applyStyle() {
        val v = view ?: return
        if (!::lp.isInitialized) return
        val a = prefs.getInt(Prefs.OPACITY, 65).coerceIn(10, 100)
        v.background = GradientDrawable().apply {
            cornerRadius = dp(10).toFloat()
            setColor(Color.argb(a * 255 / 100, 0, 0, 0))
            setStroke(dp(1), Color.argb(110, 0, 230, 118))
        }
        val locked = prefs.getBoolean(Prefs.LOCKED, false)
        lp.flags = if (locked) baseFlags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE else baseFlags
        if (v.isAttachedToWindow) wm.updateViewLayout(v, lp)
    }

    // ---------------------------------------------------------------- örnekleme

    private fun batteryTemp(): Float? {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return null
        val t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        return if (t == Int.MIN_VALUE) null else t / 10f
    }

    private fun startWorker() {
        val script = try {
            assets.open("sample.sh").bufferedReader().use { it.readText() }
        } catch (_: Throwable) {
            ""
        }
        val pm = getSystemService(PowerManager::class.java)
        val am = getSystemService(ActivityManager::class.java)
        val sampler = Sampler(script, packageName)

        val th = Thread({
            val mi = ActivityManager.MemoryInfo()
            try {
                while (alive) {
                    val t0 = SystemClock.elapsedRealtime()

                    // Ekran kapalıyken ölçme, pil harcama.
                    if (!pm.isInteractive) {
                        Thread.sleep(2000)
                        continue
                    }

                    val ok = Shell.ready()
                    val snap = if (ok) runCatching { sampler.sample() }.getOrNull() else null

                    am.getMemoryInfo(mi)
                    val used = mi.totalMem - mi.availMem
                    val ramPct = (used * 100f / mi.totalMem).roundToInt()
                    val ramGb = used / 1073741824f

                    // FPS son zamanlardaki zirvenin %80'inin altına inerse sarı yanar.
                    val fps = snap?.fps
                    if (fps != null) fpsPeak = maxOf(fpsPeak * 0.98f, fps) else fpsPeak = 0f
                    val warn = fps != null && (fps <= 0f || fps < fpsPeak * 0.8f)

                    val text = Render.build(ok, snap, warn, ramGb, ramPct, batteryTemp())
                    main.post { if (alive) view?.text = text }

                    val wait = prefs.getInt(Prefs.INTERVAL, 1000) - (SystemClock.elapsedRealtime() - t0)
                    if (wait > 0) Thread.sleep(wait)
                }
            } catch (_: InterruptedException) {
            }
        }, "gamemon-sampler")
        th.isDaemon = true
        th.start()
        worker = th
    }
}
