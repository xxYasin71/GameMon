exec 2>&1
echo "== GameMon teshis raporu"
echo "board=$(getprop ro.board.platform) soc=$(getprop ro.soc.model) hw=$(getprop ro.hardware) sdk=$(getprop ro.build.version.sdk) os=$(getprop ro.mi.os.version.name)"
sleep 10
echo "== FG"
dumpsys activity activities | grep 'ResumedActivity' | head -n 4
echo "== KATMANLAR"
dumpsys SurfaceFlinger --list | grep -v 'Background for' | head -n 30
echo "== LATENCY"
dumpsys SurfaceFlinger --list | grep 'SurfaceView' | grep -v 'Background for' | head -n 3 | while read -r L; do
  echo "-- $L"
  dumpsys SurfaceFlinger --latency "$L" < /dev/null | head -n 5
done
echo "== TERMAL BOLGELER"
for z in /sys/class/thermal/thermal_zone*; do
  echo "$(cat "$z/type") $(cat "$z/temp")"
done
echo "== THERMALSERVICE"
dumpsys thermalservice | grep 'mValue=' | head -n 40
echo "== GPU YOLLARI"
ls -d /sys/kernel/ged/hal /sys/kernel/gpu /sys/class/kgsl/kgsl-3d0 /sys/class/devfreq/* /sys/devices/platform/*mali* /sys/devices/platform/soc/*mali* /proc/gpufreq* /proc/mali 2>&1 | head -n 40
for f in /sys/kernel/ged/hal/gpu_utilization /sys/kernel/ged/hal/current_freqency /sys/class/devfreq/*/cur_freq; do
  echo "$f: $(cat "$f" 2>&1 | head -c 80)"
done
echo "== BITTI"
