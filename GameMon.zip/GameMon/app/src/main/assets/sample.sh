# GameMon örnekleyici. Başlık (MODE, PKG, ZONES, WANT_FG, WANT_DT) uygulama tarafından eklenir.
exec 2>/dev/null

if [ "$MODE" = "discover" ]; then
  for z in /sys/class/thermal/thermal_zone*; do
    echo "$z $(cat "$z/type")"
  done
  exit 0
fi

echo "@@STAT"
head -n 1 /proc/stat

echo "@@CPUF"
cat /sys/devices/system/cpu/cpu[0-9]*/cpufreq/scaling_cur_freq

if [ -n "$ZONES" ]; then
  echo "@@ZONES"
  for z in $ZONES; do
    echo "$z $(cat "$z/temp")"
  done
fi

if [ "$WANT_DT" = "1" ]; then
  echo "@@DT"
  dumpsys thermalservice | grep 'mValue='
fi

echo "@@GPU"
for f in /sys/class/kgsl/kgsl-3d0/gpu_busy_percentage /sys/class/kgsl/kgsl-3d0/gpubusy /sys/kernel/gpu/gpu_busy /sys/kernel/ged/hal/gpu_utilization /sys/devices/platform/*mali*/utilization; do
  [ -r "$f" ] && echo "$f $(cat "$f")"
done

echo "@@GPUF"
for f in /sys/class/kgsl/kgsl-3d0/gpuclk /sys/class/kgsl/kgsl-3d0/devfreq/cur_freq /sys/class/devfreq/*mali*/cur_freq /sys/class/devfreq/*gpu*/cur_freq /sys/kernel/ged/hal/current_freqency; do
  [ -r "$f" ] && echo "$f $(cat "$f")"
done

if [ "$WANT_FG" = "1" ]; then
  echo "@@FG"
  dumpsys activity activities | grep 'ResumedActivity' | head -n 12
fi

if [ -n "$PKG" ]; then
  dumpsys SurfaceFlinger --list | grep -F "$PKG" | grep -v 'Background for' | head -n 6 | while read -r L; do
    echo "@@LAT $L"
    dumpsys SurfaceFlinger --latency "$L" < /dev/null
  done
fi

echo "@@END"
