# GameMon

Oyun sırasında ekranın üstünde küçük, yarı saydam bir pencerede FPS, CPU/GPU yükü, frekans, sıcaklık, RAM ve pil sıcaklığını gösterir. Koyu tema: siyah, yeşil, sarı. Sadece Kotlin standart kütüphanesi ve Shizuku API'si kullanır, ek kütüphane yok.

## Neden Shizuku?
Android, normal uygulamaların başka bir uygulamanın FPS'ini ya da CPU/GPU yükünü okumasına izin vermez. GameMon bu verileri Shizuku ile shell yetkisiyle okur (LADB'de çalışan komutlarla aynı yetki). Root gerekmez.

## APK üretme
**Bilgisayarda:** Android Studio ile bu klasörü aç, `Build > Build APK(s)`.
**Bilgisayarsız:** Klasörü bir GitHub deposuna yükle. `Actions > APK derle > Run workflow` çalıştır, bitince çıkan `GameMon-apk` dosyasını indir (içinden `app-release.apk`).

## Telefonda kurulum
1. Shizuku'yu kur ve başlat (Kablosuz hata ayıklama ile eşleştirme, LADB'deki gibi). Telefon yeniden başlayınca Shizuku'yu tekrar başlatman gerekir.
2. GameMon'u aç: Shizuku iznini, üstte gösterme iznini ve bildirim iznini ver.
3. "Pencereyi başlat"a bas, pencereyi sürükleyip yerleştir, "Konumu kilitle"yi aç.
4. HyperOS'ta pil için GameMon'u "Kısıtlama yok" yap ve son uygulamalarda kilitle, yoksa arka planda kapanabilir.

## Bilinmesi gerekenler
- FPS, ön plandaki uygulamanın `SurfaceFlinger` katman kayıtlarından hesaplanır. Bazı oyun/Android sürümlerinde katman bulunamazsa `--` görünür.
- GPU yükü ve frekansı çekirdeğin sysfs'te açtığı dosyalara bağlıdır. Qualcomm (kgsl), Mali/Exynos ve MediaTek yolları denenir; hiçbiri okunamazsa `--` görünür.
- CPU/GPU sıcaklığı termal bölgelerden alınır, bulunamazsa `dumpsys thermalservice` denenir.
- FPS sarı olursa son zamanlardaki zirvenin %80'inin altına inmiş demektir. CPU/GPU yükü %85, sıcaklık 75° (pil 42°), RAM %90 üstünde de sarı yanar.
- Ekran kapalıyken ölçüm durur, pil harcamaz.
