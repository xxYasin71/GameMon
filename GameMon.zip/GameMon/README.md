# GameMon

Oyun sırasında ekranın üstünde küçük, yarı saydam bir pencerede FPS, CPU kullanımı, RAM kullanımı, pil sıcaklığı ve cihaz yüzey sıcaklığını gösterir. Koyu tema: siyah, yeşil, sarı. Sadece Kotlin standart kütüphanesi ve Shizuku API'si kullanır, ek kütüphane yok.

## Neden Shizuku?
Android, normal uygulamaların başka bir uygulamanın FPS'ini ya da CPU/GPU yükünü okumasına izin vermez. GameMon bu verileri Shizuku ile shell yetkisiyle okur (LADB'de çalışan komutlarla aynı yetki). Root gerekmez.

## APK üretme
**Bilgisayarda:** Android Studio ile bu klasörü aç, `Build > Build APK(s)`.
**Bilgisayarsız:** Klasörü bir GitHub deposuna yükle. `Actions > APK derle > Run workflow` çalıştır, bitince çıkan `GameMon-apk` dosyasını indir (içinden `app-release.apk`).

## Telefonda kurulum
1. Shizuku'yu kur ve başlat (Kablosuz hata ayıklama ile eşleştirme, LADB'deki gibi). Telefon yeniden başlayınca Shizuku'yu tekrar başlatman gerekir.
2. GameMon'u aç: Shizuku iznini, üstte gösterme iznini ve bildirim iznini ver.
3. "Pencereyi başlat"a bas, pencereyi sürükleyip yerleştir, "Konumu kilitle"yi aç.
4. HyperOS'ta pil için GameMon'u "Kısıtlama yok" yap ve son uygulamalarda kilitle, yoksa arka planda kapanabilir.

## Bilinmesi gerekenler
- FPS, ön plandaki oyunun `SurfaceFlinger TimeStats` katman sayaçlarından hesaplanır. Oyun paketi hem katman adından hem TimeStats içindeki `packageName` alanından eşleştirilir; sayaç farkı yoksa TimeStats katmanının `averageFPS` değeri kullanılır. Android/HyperOS erişimi engellerse uydurma değer yerine `--` görünür.
- Pil sıcaklığı Android pil bilgisinden, cihaz yüzey sıcaklığı ise geçerli `SKIN` termal sensöründen okunur.
- FPS sarı olursa son zamanlardaki zirvenin %80'inin altına inmiş demektir. CPU kullanımı %85, pil sıcaklığı 42° veya cihaz yüzey sıcaklığı 42°; RAM kullanımı %90 üstünde de sarı yanar.
- Ekran kapalıyken ölçüm durur, pil harcamaz.

## Sorun giderme (v1.1)
Değerler boş ya da yanlışsa uygulamadaki "Sorun giderme" bölümünden "Raporu başlat"a bas, 10 saniye içinde oyuna geç, sonra "Raporu kopyala" ile raporu kopyalayıp paylaş. FPS yanında `uyg?` (ön plan uygulaması bulunamadı), `katman?` (oyunun ekran katmanı yok) ya da `kare?` (katman var ama kare bilgisi yok) yazar.
