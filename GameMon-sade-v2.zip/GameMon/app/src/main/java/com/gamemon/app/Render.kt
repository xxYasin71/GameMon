package com.gamemon.app

import android.graphics.Typeface
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import java.util.Locale
import kotlin.math.roundToInt

/** Sade yüzen pencere: yalnızca FPS, CPU, pil sıcaklığı, cihaz sıcaklığı ve RAM. */
object Render {

    val LABEL = 0xFF5FA777.toInt()
    val OK = 0xFF00FF85.toInt()
    val WARN = 0xFFFFD600.toInt()

    private const val LOAD_HIGH = 85f
    private const val RAM_HIGH = 90f
    private const val BAT_HOT_C = 42f
    private const val DEVICE_HOT_C = 42f

    private fun f(fmt: String, vararg a: Any): String = String.format(Locale.US, fmt, *a)

    private fun SpannableStringBuilder.put(text: String, color: Int, bold: Boolean = false): SpannableStringBuilder {
        val start = length
        append(text)
        setSpan(ForegroundColorSpan(color), start, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (bold) setSpan(StyleSpan(Typeface.BOLD), start, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return this
    }

    private fun value(text: String, warn: Boolean) = if (warn) WARN else OK
    private fun pct(v: Int?) = if (v == null) "--%" else f("%d%%", v)
    private fun temp(v: Float?) = if (v == null) "--°C" else f("%.1f°C", v)

    fun boot(text: String): SpannableStringBuilder = SpannableStringBuilder().put(text, OK)

    fun build(
        shellOk: Boolean,
        s: Sample?,
        fpsWarn: Boolean,
        ramGb: Float,
        ramPct: Int,
        batC: Float?
    ): SpannableStringBuilder {
        val sb = SpannableStringBuilder()

        sb.put("FPS  ", LABEL)
        val fps = s?.fps
        when {
            !shellOk -> sb.put("Shizuku bağlantısı yok", WARN, true)
            fps == null -> sb.put("--", OK, true)
            else -> sb.put(f("%d", fps.roundToInt()), if (fpsWarn) WARN else OK, true)
        }
        sb.append('\n')

        val cpu = s?.cpuPct
        sb.put("CPU  ", LABEL)
        sb.put(pct(cpu), value("", cpu?.toFloat()?.let { it >= LOAD_HIGH } == true), true)
        sb.append('\n')

        sb.put("PİL  ", LABEL)
        sb.put(temp(batC), value("", batC != null && batC >= BAT_HOT_C), true)
        sb.append('\n')

        // SKIN sensörü cihazın dış yüzey/gövde sıcaklığına en yakın sistem ölçümüdür.
        val deviceTemp = s?.skinTemp
        sb.put("CİHAZ  ", LABEL)
        sb.put(temp(deviceTemp), value("", deviceTemp != null && deviceTemp >= DEVICE_HOT_C), true)
        sb.append('\n')

        sb.put("RAM  ", LABEL)
        sb.put(pct(ramPct), value("", ramPct >= RAM_HIGH), true)
        sb.put(f("  %.1f GB", ramGb), OK)

        return sb
    }
}
